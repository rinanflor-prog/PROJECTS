const pageShell = document.querySelector(".page-shell");
const transitionLinks = document.querySelectorAll("[data-page-transition]");
const refreshLoader = document.querySelector(".refresh-loader");
let incomingDirection;

if (refreshLoader) {
	const minimumLoadingTime = performance.now() + 450;
	window.addEventListener("load", () => {
		window.setTimeout(() => {
			refreshLoader.classList.add("is-hidden");
			refreshLoader.setAttribute("aria-hidden", "true");
			window.setTimeout(() => refreshLoader.remove(), 250);
		}, Math.max(0, minimumLoadingTime - performance.now()));
	}, { once: true });
}

try {
	incomingDirection = sessionStorage.getItem("page-transition-direction");
	sessionStorage.removeItem("page-transition-direction");
} catch {}

if (incomingDirection === "forward" || incomingDirection === "backward") {
	const enteringClass = `page-entering-${incomingDirection}`;
	const enteringAnimation = incomingDirection === "forward" ? "create-card-slide-in" : "signin-card-slide-in";
	pageShell.classList.add(enteringClass);
	pageShell.addEventListener("animationend", (event) => {
		if (event.target.matches(".login-card") && event.animationName === enteringAnimation) {
			pageShell.classList.remove(enteringClass);
		}
	});
}

transitionLinks.forEach((link) => {
	link.addEventListener("click", (event) => {
		if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

		event.preventDefault();
		pageShell.classList.remove("page-entering-forward", "page-entering-backward");
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			window.location.assign(link.href);
			return;
		}

		try {
			sessionStorage.setItem("page-transition-direction", link.dataset.pageTransition);
		} catch {}

		pageShell.classList.add(`page-leaving-${link.dataset.pageTransition}`);
		window.setTimeout(() => window.location.assign(link.href), 420);
	});
});