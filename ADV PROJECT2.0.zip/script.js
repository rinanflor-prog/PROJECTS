const form = document.querySelector("#login-form");
const passwordInput = document.querySelector("#password");
const togglePassword = document.querySelector("#toggle-password");
const formMessage = document.querySelector("#form-message");
const loginLayout = document.querySelector(".login-layout");
const portal = document.querySelector("#portal-app");
const appShell = document.querySelector(".page-shell");
const toast = document.querySelector("#toast");
const themeModeStorageKey = "student-portal-theme-mode";
const sessionAccountStorageKey = "student-portal-session-account";
const rememberedAccountStorageKey = "student-portal-remembered-account";
const themeCheckInterval = 60 * 1000;
let toastTimer;
let currentAccount;
let activePage = "dashboard";
let themeMode = "auto";
let isDarkMode;
let enrollmentStep = "select";
let enrollmentConfirmed = false;
let paymentMethod = "GCash";
let announcementFilter = "All";
let corRequestSubmitted = false;
const selectedSubjects = new Set();

function isNightTime(date = new Date()) {
	const hour = date.getHours();
	return hour >= 18 || hour < 6;
}

function getTimeGreeting(date = new Date()) {
	const hour = date.getHours();
	if (hour >= 5 && hour < 12) return "Good morning";
	if (hour >= 12 && hour < 17) return "Good afternoon";
	return "Good evening";
}

function updateDashboardDateTime(date = new Date()) {
	const greeting = portal.querySelector("#dashboard-greeting");
	const dateTime = portal.querySelector("#dashboard-datetime");
	if (!greeting || !dateTime || !currentAccount) return;

	const firstName = currentAccount.fullName.split(/\s+/)[0];
	const formattedDate = new Intl.DateTimeFormat("en-PH", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	}).format(date);
	const formattedTime = new Intl.DateTimeFormat("en-PH", {
		hour: "numeric",
		minute: "2-digit"
	}).format(date);

	greeting.textContent = `${getTimeGreeting(date)}, ${firstName}`;
	dateTime.textContent = `1st Semester, A.Y. 2026–2027 · ${formattedDate} · ${formattedTime}`;
}

function saveSignedInAccount(account, rememberMe) {
	sessionStorage.removeItem(sessionAccountStorageKey);
	localStorage.removeItem(rememberedAccountStorageKey);
	const storage = rememberMe ? localStorage : sessionStorage;
	const storageKey = rememberMe ? rememberedAccountStorageKey : sessionAccountStorageKey;
	storage.setItem(storageKey, account.studentId);
}

function clearSignedInAccount() {
	sessionStorage.removeItem(sessionAccountStorageKey);
	localStorage.removeItem(rememberedAccountStorageKey);
}

try {
	const savedThemeMode = localStorage.getItem(themeModeStorageKey);
	if (savedThemeMode === "light" || savedThemeMode === "dark" || savedThemeMode === "auto") {
		themeMode = savedThemeMode;
	}
} catch (error) {
	console.error("Could not read the saved portal theme mode.", error);
}
isDarkMode = themeMode === "auto" ? isNightTime() : themeMode === "dark";

const navigation = [
	["dashboard", "Dashboard", "▦"],
	["schedule", "Class Schedule", "▤"],
	["grades", "Grades", "▥"],
	["enrollment", "Enrollment", "□"],
	["payments", "Payments", "◉"],
	["announcements", "Announcements", "♧"],
	["support", "Help & Support", "?"]
];

const subjects = [
	{ code: "PE 3", name: "Physical Activity Toward Health and Fitness", units: 2, days: ["T"], time: "08:00 AM – 10:00 AM", room: "COVER: PE", section: "—" },
	{ code: "IS 103", name: "IT Infrastructure and Network Technologies", units: 3, days: ["T", "TH"], time: "01:00 PM – 04:00 PM", room: "NB5-10", section: "BSIS-S3" },
	{ code: "DM 102", name: "Financial Management", units: 3, days: ["T", "TH"], time: "04:00 PM – 05:30 PM", room: "NB5-10", section: "BSIS-S3" },
	{ code: "ACCTG 12", name: "Fundamentals of Accounting 2", units: 3, days: ["T", "TH"], time: "05:30 PM – 08:30 PM", room: "NB5-10", section: "BSIS-S3" },
	{ code: "CC 104", name: "Data Structures and Algorithms", units: 3, days: ["M", "W", "F"], time: "02:00 PM – 04:00 PM", room: "NB5-10", section: "BSIS-S3" },
	{ code: "IS 104", name: "Systems Analysis and Design", units: 3, days: ["M", "W", "F"], time: "04:30 PM – 06:30 PM", room: "NB5-10", section: "BSIS-S3" },
	{ code: "ADV 02", name: "Human Computer Interaction", units: 3, days: ["M", "W", "F"], time: "06:30 PM – 07:30 PM", room: "NB5-10", section: "BSIS-S3" }
];
const dayLabels = { M: "Mon", T: "Tue", W: "Wed", TH: "Thu", F: "Fri" };
const todayCode = ["SU", "M", "T", "W", "TH", "F", "SA"][new Date().getDay()];
subjects.forEach(({ code }) => selectedSubjects.add(code));

const grades = subjects.map(({ code, name, units }) => [code, name, String(units), "—", "—", "—", "—", "Not yet posted"]);
const maxEnrollmentUnits = 24;
const selectedUnitTotal = () => subjects
	.filter(({ code }) => selectedSubjects.has(code))
	.reduce((total, { units }) => total + units, 0);

const announcements = [
	{ category: "Academic", title: "Final exam schedule posted", body: "Check your exam dates under Class Schedule. Bring your school ID on exam days.", age: "2 days ago", unread: true },
	{ category: "Finance", title: "Reminder: balance due on November 20", body: "Settle your remaining balance through the Payments page to avoid late fees.", age: "3 days ago", unread: true },
	{ category: "Campus", title: "Library hours extended", body: "The library stays open until 8:00 PM during exam week.", age: "4 days ago", unread: true },
	{ category: "Academic", title: "Enrollment for the 2nd semester opens soon", body: "Prepare your subject list and clear any pending balance first.", age: "1 week ago", unread: false }
];

function escapeHTML(value) {
	return String(value).replace(/[&<>"']/g, (character) => ({
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		'"': "&quot;",
		"'": "&#39;"
	})[character]);
}

function showToast(message) {
	window.clearTimeout(toastTimer);
	toast.textContent = message;
	toast.classList.add("is-visible");
	toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
}

function renderTable(headers, rows, className = "") {
	return `<div class="table-wrap"><table class="${className}"><thead><tr>${headers.map((header) => `<th scope="col">${header}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
}

function renderDashboard() {
	const recentGradeRows = grades.slice(0, 3).map(([code, subject, , prelim, midterm, semifinal, final]) =>
		`<tr><td>${code} · ${subject}</td><td>${prelim}</td><td>${midterm}</td><td>${semifinal}</td><td>${final}</td></tr>`
	);
	const todayClasses = subjects.filter(({ days }) => days.includes(todayCode));
	const todayClassRows = todayClasses.length
		? todayClasses.map(({ time, name, room }) => `<div class="class-row"><span>${time}</span><div><strong>${name}</strong><small>${room}</small></div></div>`).join("")
		: '<p class="panel-note">No classes scheduled for today.</p>';

	return `
		<header class="portal-header">
			<div><h1 id="dashboard-greeting"></h1><p id="dashboard-datetime"></p></div>
			<div class="header-tools"><label class="sr-only" for="portal-search">Search the portal</label><input id="portal-search" type="search" placeholder="Search subjects, grades, announcements"><label class="sr-only" for="theme-mode">Color theme</label><select class="theme-select" id="theme-mode" aria-label="Color theme"><option value="auto" ${themeMode === "auto" ? "selected" : ""}>Auto</option><option value="light" ${themeMode === "light" ? "selected" : ""}>Light</option><option value="dark" ${themeMode === "dark" ? "selected" : ""}>Dark</option></select><button class="notification-button" type="button" data-page="announcements" aria-label="Notifications">♧<span class="notification-count">3</span></button></div>
		</header>
		<div class="stat-grid">
			<article class="stat-card"><span>Current GPA</span><strong>—</strong><small class="status-pending">No grades posted yet</small></article>
			<article class="stat-card"><span>Enrolled Units</span><strong>20</strong><small>7 subjects this semester</small></article>
			<article class="stat-card"><span>Attendance</span><strong>94%</strong><div class="progress-track"><span></span></div></article>
			<article class="stat-card"><span>Balance Due</span><strong>₱4,500</strong><small class="status-pending">Due Nov 20 · Upcoming</small></article>
		</div>
		<div class="dashboard-grid">
			<div class="dashboard-main">
				<section class="panel">
					<div class="panel-heading"><h2>Today’s Classes</h2><button class="text-button" type="button" data-page="schedule">View full schedule</button></div>
					<div class="class-list">${todayClassRows}</div>
				</section>
				<section class="panel">
					<div class="panel-heading"><h2>Recent Grades</h2><button class="text-button" type="button" data-page="grades">See all grades</button></div>
					${renderTable(["Subject", "Prelim", "Midterm", "Semifinal", "Final"], recentGradeRows, "compact-table")}
				</section>
			</div>
			<div class="dashboard-side">
				<section class="panel">
					<h2>Quick Actions</h2>
					<div class="quick-actions"><button type="button" data-page="enrollment">Enroll</button><button type="button" data-page="payments">Pay Fees</button><button class="secondary-action" type="button" data-action="request-cor">Request COR</button><button class="secondary-action" type="button" data-action="download-grades">Download Grades</button></div>
				</section>
				<section class="panel">
					<h2>Upcoming Deadlines</h2>
					<ul class="deadline-list">
						<li><span class="date-tile"><b>NOV</b>16</span><div><strong>HCI Final Project</strong><small>Due in 10 days</small></div></li>
						<li><span class="date-tile gold"><b>NOV</b>20</span><div><strong>Tuition Payment</strong><small>₱4,500 balance</small></div></li>
						<li><span class="date-tile"><b>NOV</b>25</span><div><strong>CC 104 Lab Activity</strong><small>Submit via portal</small></div></li>
					</ul>
				</section>
				<section class="panel announcement-preview">
					<h2>Announcements</h2>
					<strong>Final exam schedule posted</strong><p>Check your exam dates under Class Schedule. · 2 days ago</p>
					<button class="text-button" type="button" data-page="announcements">View all announcements</button>
				</section>
			</div>
		</div>
		<p class="sample-note">Sample data for prototype purposes only.</p>`;
}

function renderSchedule() {
	const rows = subjects.map(({ code, name, units, days, time, room, section }) => {
		const isToday = days.includes(todayCode);
		const dayNames = days.map((day) => dayLabels[day]).join(", ");
		return `<tr class="${isToday ? "today-row" : ""}"><td>${code}</td><td>${name}</td><td>${units}</td><td>${dayNames}${isToday ? " · Today" : ""}</td><td>${time}</td><td>${room}</td><td>${section}</td></tr>`;
	});
	return `<header class="portal-header"><div><h1>Class Schedule</h1><p>1st Semester, A.Y. 2026–2027 · Today's classes are highlighted</p></div></header>${renderTable(["Course Code", "Subject", "Units", "Days", "Time", "Room", "Section"], rows, "schedule-table")}<p class="sample-note">Schedule details are based on the provided enrollment report.</p>`;
}

function renderGrades() {
	const rows = grades.map(([code, subject, units, prelim, midterm, semifinal, final, status]) => `<tr><td>${code} · ${subject}</td><td>${units}</td><td>${prelim}</td><td>${midterm}</td><td>${semifinal}</td><td>${final}</td><td class="status-pending">● ${status}</td></tr>`);
	return `<header class="portal-header"><div><h1>Grades</h1><p>1st Semester, A.Y. 2026–2027 · 20 units</p></div><button class="primary-button" type="button" data-action="print-grades">Download Grades (PDF)</button></header>${renderTable(["Subject", "Units", "Prelim", "Midterm", "Semifinal", "Final", "Status"], rows, "grades-table")}<p class="sample-note">Grades have not been provided for these subjects.</p>`;
}

function renderEnrollment() {
	const count = selectedSubjects.size;
	const totalUnits = selectedUnitTotal();
	if (enrollmentConfirmed) {
		return `<header class="portal-header"><div><h1>Enrollment</h1><p>1st Semester, A.Y. 2026–2027</p></div></header><section class="panel confirmation-panel"><div class="success-mark">✓</div><h2>Enrollment submitted</h2><p>Your subject selection for the 1st semester has been saved in this demo.</p><button class="primary-button" type="button" data-action="edit-enrollment">Edit subject selection</button></section>`;
	}
	if (enrollmentStep === "confirm") {
		return `<header class="portal-header"><div><h1>Enrollment</h1><p>1st Semester, A.Y. 2026–2027 · Confirm your subjects</p></div></header><div class="step-indicator"><span>1. Review profile</span><span>2. Select subjects</span><strong>3. Confirm</strong></div><section class="panel"><h2>Selected subjects</h2><ul class="selected-subjects">${subjects.filter(({ code }) => selectedSubjects.has(code)).map(({ code, name, units, days, time }) => `<li><span>${code} · ${name}</span><small>${days.map((day) => dayLabels[day]).join(", ")} · ${time}</small><b>${units} units</b></li>`).join("")}</ul><p class="unit-summary">Total: <strong>${totalUnits} units</strong> · Maximum ${maxEnrollmentUnits} units</p><div class="button-row"><button class="secondary-button" type="button" data-action="back-enrollment">Back</button><button class="primary-button" type="button" data-action="confirm-enrollment">Confirm Enrollment</button></div></section><p class="sample-note">Sample data for prototype purposes only.</p>`;
	}
	const rows = subjects.map(({ code, name, units, days, time, room }) => `<tr><td><input class="subject-checkbox" type="checkbox" value="${code}" aria-label="Select ${code} ${name}" ${selectedSubjects.has(code) ? "checked" : ""}></td><td>${code}</td><td>${name}</td><td>${units}</td><td>${days.map((day) => dayLabels[day]).join(", ")}</td><td>${time}</td><td>${room}</td></tr>`);
	return `<header class="portal-header"><div><h1>Enrollment</h1><p>1st Semester, A.Y. 2026–2027 · Select your subjects</p></div></header><div class="step-indicator"><span>1. Review profile</span><strong>2. Select subjects</strong><span>3. Confirm</span></div>${renderTable(["Select", "Code", "Subject", "Units", "Days", "Time", "Room"], rows, "enrollment-table")}<div class="enrollment-footer"><p class="unit-summary">Total: <strong id="unit-total">${totalUnits} units</strong> · Maximum ${maxEnrollmentUnits} units · ${count} subjects</p><button class="primary-button" type="button" data-action="continue-enrollment">Continue to Confirm</button></div><p class="sample-note">Subjects and schedule are based on the provided enrollment report.</p>`;
}

function renderPayments() {
	const methods = ["GCash", "Maya", "Bank transfer", "Pay at the cashier"];
	return `<header class="portal-header"><div><h1>Payments</h1><p>1st Semester, A.Y. 2026–2027</p></div></header><div class="payment-grid"><section class="panel"><h2>Fee Summary</h2><dl class="fee-list"><div><dt>Tuition</dt><dd>₱18,000</dd></div><div><dt>Miscellaneous</dt><dd>₱3,500</dd></div><div><dt>Laboratory</dt><dd>₱2,000</dd></div><div class="status-good"><dt>Paid so far</dt><dd>− ₱19,000</dd></div><div class="fee-total"><dt>Balance due Nov 20</dt><dd>₱4,500</dd></div></dl></section><section class="panel pay-panel"><h2>Pay Balance: ₱4,500</h2><fieldset class="payment-methods"><legend class="sr-only">Choose a payment method</legend>${methods.map((method) => `<label><input type="radio" name="payment-method" value="${method}" ${paymentMethod === method ? "checked" : ""}>${method}</label>`).join("")}</fieldset><button class="primary-button full-button" type="button" data-action="pay">Pay ₱4,500 Now</button><p class="panel-note">You will review the details before you confirm.</p></section><section class="panel history-panel"><h2>Payment History</h2>${renderTable(["Date", "Amount", "Status"], ["Sep 15, 2026|₱9,000", "Aug 12, 2026|₱10,000"].map((item) => { const [date, amount] = item.split("|"); return `<tr><td>${date}</td><td>${amount}</td><td class="status-good">✓ Received</td></tr>`; }))}</section></div><p class="sample-note">Sample data for prototype purposes only.</p>`;
}

function renderAnnouncements() {
	const filtered = announcements.filter((item) => announcementFilter === "All" || item.category === announcementFilter);
	return `<header class="portal-header"><div><h1>Announcements</h1><p>3 unread</p></div><label class="filter-label">Filter by category<select id="announcement-filter"><option${announcementFilter === "All" ? " selected" : ""}>All</option><option${announcementFilter === "Academic" ? " selected" : ""}>Academic</option><option${announcementFilter === "Finance" ? " selected" : ""}>Finance</option><option${announcementFilter === "Campus" ? " selected" : ""}>Campus</option></select></label></header><div class="announcement-list">${filtered.map((item) => `<article class="panel announcement-card">${item.unread ? '<span class="pill new-pill">New</span>' : ""}<span class="pill">${item.category}</span><h2>${item.title}</h2><p>${item.body} · ${item.age}</p></article>`).join("") || '<section class="panel"><p>No announcements in this category.</p></section>'}<p class="sample-note">Sample data for prototype purposes only.</p></div>`;
}

function renderSupport() {
	return `<header class="portal-header"><div><h1>Help &amp; Support</h1><p>Find quick answers or send a message to the registrar.</p></div></header><div class="support-grid"><section class="panel faq-panel"><h2>Frequently Asked Questions</h2><details open><summary>How do I enroll in subjects?</summary><p>Open Enrollment, select your subjects, then confirm. Your total units must not exceed 24.</p></details><details><summary>Where can I see my grades?</summary><p>Open Grades from the sidebar to review your midterm and final marks.</p></details><details><summary>How do I pay my balance?</summary><p>Open Payments, choose a payment method, and review the balance before proceeding.</p></details><details><summary>I forgot my password. What do I do?</summary><p>Contact the registrar using the contact form and include your Student ID.</p></details></section><section class="panel contact-panel"><h2>Contact the Registrar</h2><form id="support-form"><label class="field-label" for="support-topic">Topic</label><select id="support-topic" required><option>Enrollment</option><option>Grades</option><option>Payments</option><option>Account access</option><option>Other</option></select><label class="field-label" for="support-message">Your message</label><textarea id="support-message" placeholder="Describe your concern" required></textarea><button class="primary-button full-button" type="submit">Send Message</button><p class="panel-note">Replies usually arrive within 1–2 school days.</p></form></section></div><p class="sample-note">Sample content for prototype purposes only.</p>`;
}

function renderCorRequest() {
	if (corRequestSubmitted) {
		return `<header class="portal-header"><div><h1>Request COR</h1><p>Certificate of Registration · 1st Semester, A.Y. 2026–2027</p></div></header><section class="panel confirmation-panel"><div class="success-mark">✓</div><h2>Request submitted</h2><p>Your Certificate of Registration request has been recorded in this demo.</p><button class="secondary-button" type="button" data-action="new-cor-request">Submit another request</button></section>`;
	}
	return `<header class="portal-header"><div><h1>Request COR</h1><p>Request a copy of your Certificate of Registration.</p></div></header><section class="panel contact-panel cor-panel"><form id="cor-form"><label class="field-label" for="cor-semester">Semester</label><select id="cor-semester" required><option>1st Semester, A.Y. 2026–2027</option><option>2nd Semester, A.Y. 2025–2026</option><option>1st Semester, A.Y. 2025–2026</option></select><label class="field-label" for="cor-copy">Copy type</label><select id="cor-copy" required><option>Digital copy</option><option>Printed copy</option></select><label class="field-label" for="cor-purpose">Purpose of request</label><textarea id="cor-purpose" placeholder="e.g. Scholarship application" required></textarea><button class="primary-button full-button" type="submit">Submit COR Request</button><p class="panel-note">This demo records the request locally; it does not send it to the registrar.</p></form></section>`;
}

const pageRenderers = {
	dashboard: renderDashboard,
	schedule: renderSchedule,
	grades: renderGrades,
	enrollment: renderEnrollment,
	payments: renderPayments,
	announcements: renderAnnouncements,
	support: renderSupport,
	"cor-request": renderCorRequest
};

function renderPortal() {
	const navPage = activePage === "cor-request" ? "support" : activePage;
	const title = activePage === "cor-request" ? "Request COR" : navigation.find(([page]) => page === activePage)[1];
	appShell.classList.toggle("portal-dark", isDarkMode);
	portal.innerHTML = `
		<div class="portal-layout">
			<aside class="sidebar">
				<button class="sidebar-brand" type="button" data-page="dashboard"><span class="sidebar-mark">MC</span><strong>MyCampus</strong></button>
				<nav class="portal-nav" aria-label="Student portal">
					${navigation.map(([page, label, icon]) => `<button type="button" data-page="${page}" class="${navPage === page ? "active" : ""}" ${navPage === page ? 'aria-current="page"' : ""}><span aria-hidden="true">${icon}</span>${label}</button>`).join("")}
				</nav>
				<div class="student-profile"><span class="avatar">${escapeHTML(currentAccount.fullName.split(/\s+/).map((part) => part[0]).slice(0, 2).join("").toUpperCase())}</span><div><strong>${escapeHTML(currentAccount.fullName)}</strong><small>2nd Year, BSIS</small></div></div>
				<button class="logout-button" type="button" data-action="logout">⇥ &nbsp; Log out</button>
			</aside>
			<section class="portal-content" aria-label="${title}">${pageRenderers[activePage]()}</section>
		</div>`;
	if (activePage === "dashboard") updateDashboardDateTime();
}

function updateEnrollmentTotal() {
	const total = portal.querySelector("#unit-total");
	if (total) total.textContent = `${selectedUnitTotal()} units`;
}

function downloadGrades() {
	const csvRows = [
		["Course Code", "Subject", "Units", "Prelim", "Midterm", "Semifinal", "Final", "Status"],
		...grades.map((grade) => grade.map((value) => value === "—" ? "" : value))
	];
	const csv = csvRows.map((row) => row.map((value) => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n");
	const file = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
	const downloadUrl = URL.createObjectURL(file);
	const link = document.createElement("a");
	link.href = downloadUrl;
	link.download = "student-grades.csv";
	document.body.append(link);
	link.click();
	link.remove();
	window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
}

togglePassword.addEventListener("click", () => {
	const isPasswordHidden = passwordInput.type === "password";
	passwordInput.type = isPasswordHidden ? "text" : "password";
	togglePassword.textContent = isPasswordHidden ? "Hide" : "Show";
	togglePassword.setAttribute("aria-pressed", String(isPasswordHidden));
	togglePassword.setAttribute("aria-label", isPasswordHidden ? "Hide password" : "Show password");
});

form.addEventListener("submit", async (event) => {
	event.preventDefault();
	if (!form.reportValidity()) return;

	formMessage.classList.remove("is-error");
	formMessage.textContent = "";
	try {
		const account = await window.demoAuth.signIn(
			document.querySelector("#student-id").value,
			passwordInput.value
		);
		if (!account) throw new Error("Student ID or password is incorrect.");
		try {
			saveSignedInAccount(account, form.elements.remember.checked);
		} catch (storageError) {
			console.error("Could not save the sign-in session.", storageError);
			showToast("Signed in, but this browser could not save your session.");
		}
		currentAccount = account;
		activePage = "dashboard";
		loginLayout.hidden = true;
		portal.hidden = false;
		appShell.classList.add("portal-active");
		renderPortal();
	} catch (error) {
		formMessage.classList.add("is-error");
		formMessage.textContent = error.message;
	}
});

document.querySelector("#forgot-link").addEventListener("click", (event) => {
	event.preventDefault();
	const studentId = document.querySelector("#student-id");
	if (!studentId.value) studentId.focus();
	showToast(studentId.value
		? "Password recovery is not connected yet. Please contact the registrar."
		: "Enter your Student ID first, then contact the registrar for help.");
});

portal.addEventListener("click", (event) => {
	const target = event.target;
	if (!(target instanceof Element)) return;
	const pageButton = target.closest("[data-page]");
	if (pageButton) {
		activePage = pageButton.dataset.page;
		renderPortal();
		return;
	}

	const action = target.closest("[data-action]")?.dataset.action;
	if (action === "logout") {
		try {
			clearSignedInAccount();
		} catch (error) {
			console.error("Could not clear the saved sign-in session.", error);
			showToast("Signed out, but the saved session could not be cleared.");
		}
		currentAccount = null;
		portal.hidden = true;
		loginLayout.hidden = false;
		appShell.classList.remove("portal-active");
		form.reset();
		formMessage.textContent = "";
		document.querySelector("#student-id").focus();
	} else if (action === "request-cor") {
		corRequestSubmitted = false;
		activePage = "cor-request";
		renderPortal();
	} else if (action === "new-cor-request") {
		corRequestSubmitted = false;
		renderPortal();
	} else if (action === "download-grades") {
		downloadGrades();
		showToast("Your grades were downloaded as a CSV file.");
	} else if (action === "print-grades") {
		window.print();
	} else if (action === "continue-enrollment") {
		if (selectedSubjects.size === 0) {
			showToast("Select at least one subject to continue.");
			return;
		}
		enrollmentStep = "confirm";
		renderPortal();
	} else if (action === "back-enrollment") {
		enrollmentStep = "select";
		renderPortal();
	} else if (action === "confirm-enrollment") {
		enrollmentConfirmed = true;
		renderPortal();
		showToast("Your subject selection has been submitted in this demo.");
	} else if (action === "edit-enrollment") {
		enrollmentConfirmed = false;
		enrollmentStep = "select";
		renderPortal();
	} else if (action === "pay") {
		showToast(`${paymentMethod} selected. Payment processing is not connected in this demo.`);
	}
});

portal.addEventListener("change", (event) => {
	const target = event.target;
	if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;
	if (target.matches(".subject-checkbox")) {
		const subject = subjects.find(({ code }) => code === target.value);
		if (!subject) return;
		if (target.checked && selectedUnitTotal() + subject.units > maxEnrollmentUnits) {
			target.checked = false;
			showToast("You cannot enroll in more than 24 units.");
			return;
		}
		if (target.checked) selectedSubjects.add(target.value);
		else selectedSubjects.delete(target.value);
		updateEnrollmentTotal();
	} else if (target.name === "payment-method") {
		paymentMethod = target.value;
	} else if (target.id === "announcement-filter") {
		announcementFilter = target.value;
		renderPortal();
	} else if (target.id === "theme-mode") {
		themeMode = target.value;
		isDarkMode = themeMode === "auto" ? isNightTime() : themeMode === "dark";
		try {
			localStorage.setItem(themeModeStorageKey, themeMode);
		} catch (error) {
			console.error("Could not save the portal theme mode.", error);
			showToast("Theme changed, but your preference could not be saved.");
		}
		renderPortal();
	}
});

async function restoreSignedInAccount() {
	let savedStudentId;
	try {
		savedStudentId = localStorage.getItem(rememberedAccountStorageKey)
			|| sessionStorage.getItem(sessionAccountStorageKey);
	} catch (error) {
		console.error("Could not read the saved sign-in session.", error);
		formMessage.classList.add("is-error");
		formMessage.textContent = "Could not restore your sign-in session. Please sign in again.";
		return;
	}
	if (!savedStudentId) return;

	try {
		const account = window.demoAuth.getAccount(savedStudentId);
		if (!account) {
			clearSignedInAccount();
			return;
		}
		currentAccount = account;
		activePage = "dashboard";
		loginLayout.hidden = true;
		portal.hidden = false;
		appShell.classList.add("portal-active");
		renderPortal();
	} catch (error) {
		console.error("Could not restore the saved student account.", error);
		formMessage.classList.add("is-error");
		formMessage.textContent = "Could not restore your account. Please sign in again.";
	}
}

restoreSignedInAccount();

window.setInterval(() => {
	if (!currentAccount) return;
	if (activePage === "dashboard") updateDashboardDateTime();
	if (themeMode === "auto") {
		const shouldUseDarkMode = isNightTime();
		if (shouldUseDarkMode !== isDarkMode) {
			isDarkMode = shouldUseDarkMode;
			renderPortal();
		}
	}
}, themeCheckInterval);

portal.addEventListener("submit", (event) => {
	if (!(event.target instanceof HTMLFormElement)) return;
	if (event.target.id === "cor-form") {
		event.preventDefault();
		if (!event.target.reportValidity()) return;
		corRequestSubmitted = true;
		renderPortal();
		showToast("Your COR request was recorded in this demo.");
		return;
	}
	if (event.target.id !== "support-form") return;
	event.preventDefault();
	if (!event.target.reportValidity()) return;
	event.target.reset();
	showToast("Your message has been recorded in this demo.");
});

portal.addEventListener("keydown", (event) => {
	if (!(event.target instanceof HTMLInputElement) || event.target.id !== "portal-search" || event.key !== "Enter") return;
	const query = event.target.value.trim().toLowerCase();
	if (!query) return;
	const match = navigation.find(([, label]) => label.toLowerCase().includes(query));
	if (match) {
		activePage = match[0];
		renderPortal();
	} else {
		showToast("No portal section matched your search.");
	}
});
