const form = document.querySelector("#create-account-form");
const passwordInput = document.querySelector("#password");
const confirmPasswordInput = document.querySelector("#confirm-password");
const formMessage = document.querySelector("#form-message");

document.querySelectorAll("[data-toggle-password]").forEach((button) => {
	button.addEventListener("click", () => {
		const input = document.getElementById(button.dataset.togglePassword);
		const isPasswordHidden = input.type === "password";
		input.type = isPasswordHidden ? "text" : "password";
		button.textContent = isPasswordHidden ? "Hide" : "Show";
		button.setAttribute("aria-pressed", String(isPasswordHidden));
		button.setAttribute("aria-label", isPasswordHidden ? "Hide password" : "Show password");
	});
});

function validatePasswordMatch() {
	confirmPasswordInput.setCustomValidity(
		confirmPasswordInput.value && confirmPasswordInput.value !== passwordInput.value
			? "Passwords do not match."
			: ""
	);
}

passwordInput.addEventListener("input", validatePasswordMatch);
confirmPasswordInput.addEventListener("input", validatePasswordMatch);

form.addEventListener("submit", async (event) => {
	event.preventDefault();
	validatePasswordMatch();
	if (!form.reportValidity()) return;

	formMessage.classList.remove("is-error");
	formMessage.textContent = "";
	try {
		const account = await window.demoAuth.createAccount({
			fullName: document.querySelector("#full-name").value,
			studentId: document.querySelector("#student-id").value,
			password: passwordInput.value
		});
		formMessage.textContent = `Demo account created for ${account.studentId}. You can now sign in.`;
		form.reset();
	} catch (error) {
		formMessage.classList.add("is-error");
		formMessage.textContent = error.message;
	}
});